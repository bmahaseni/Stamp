# stamp-recognition
This is one of my final projects for BS
